import React from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MantineProvider } from "@mantine/core";
import { ItemViewer } from "./components/ItemViewer.jsx";
import { theme } from "./theme.js";

// Import Mantine CSS
import "@mantine/core/styles.css";

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      retryDelay: 1000,
    },
  },
});

export default function Root(props) {
  return (
    <QueryClientProvider client={queryClient}>
      <MantineProvider theme={theme}>
        <ItemViewer />
      </MantineProvider>
    </QueryClientProvider>
  );
}
